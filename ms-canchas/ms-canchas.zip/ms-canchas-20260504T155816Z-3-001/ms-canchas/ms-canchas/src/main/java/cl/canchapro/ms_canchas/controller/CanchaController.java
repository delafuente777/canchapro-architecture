package cl.canchapro.ms_canchas.controller;


import cl.canchapro.ms_canchas.model.Cancha;
import cl.canchapro.ms_canchas.model.TipoCancha;
import cl.canchapro.ms_canchas.service.CanchaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/canchas")
public class CanchaController {

    @Autowired
    private CanchaService service;

    @GetMapping
    public List<Cancha> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Cancha obtener(@PathVariable Long id) {
        return service.obtener(id);
    }

    @PostMapping
    public ResponseEntity<Cancha> crear(@Valid @RequestBody Cancha c) {
        return new ResponseEntity<>(service.crear(c), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public Cancha actualizar(@PathVariable Long id, @RequestBody Cancha c) {
        return service.actualizar(id, c);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/tipo/{tipo}")
    public List<Cancha> porTipo(@PathVariable TipoCancha tipo) {
        return service.porTipo(tipo);
    }
}


