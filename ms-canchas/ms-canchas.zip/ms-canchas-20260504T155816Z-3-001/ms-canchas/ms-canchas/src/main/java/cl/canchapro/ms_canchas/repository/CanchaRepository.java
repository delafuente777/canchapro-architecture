package cl.canchapro.ms_canchas.repository;


import cl.canchapro.ms_canchas.model.Cancha;
import cl.canchapro.ms_canchas.model.TipoCancha;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CanchaRepository extends JpaRepository<Cancha, Long> {

    List<Cancha> findByTipo(TipoCancha tipo);

    boolean existsByNombre(String nombre);
}


