package cl.canchapro.ms_canchas.model;


public enum TipoCancha {
    FUTBOL,
    TENIS,
    PADEL
}


