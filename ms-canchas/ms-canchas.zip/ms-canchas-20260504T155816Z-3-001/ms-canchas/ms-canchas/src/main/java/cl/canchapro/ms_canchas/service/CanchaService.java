package cl.canchapro.ms_canchas.service;


import cl.canchapro.ms_canchas.model.Cancha;
import cl.canchapro.ms_canchas.model.TipoCancha;
import cl.canchapro.ms_canchas.repository.CanchaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CanchaService {

    @Autowired
    private CanchaRepository repo;

    public List<Cancha> listar() {
        return repo.findAll();
    }

    public Cancha obtener(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Cancha no encontrada"));
    }

    public Cancha crear(Cancha c) {

        
        if (repo.existsByNombre(c.getNombre())) {
            throw new RuntimeException("Ya existe una cancha con ese nombre");
        }

     
        c.setDisponible(true);

        return repo.save(c);
    }

    public Cancha actualizar(Long id, Cancha nueva) {

        Cancha actual = obtener(id);

        actual.setNombre(nueva.getNombre());
        actual.setTipo(nueva.getTipo());
        actual.setUbicacion(nueva.getUbicacion());
        actual.setDisponible(nueva.isDisponible());

        return repo.save(actual);
    }

    public void eliminar(Long id) {
        if (!repo.existsById(id)) {
            throw new RuntimeException("No existe la cancha");
        }
        repo.deleteById(id);
    }

    public List<Cancha> porTipo(TipoCancha tipo) {
        return repo.findByTipo(tipo);
    }
}


